Getting started

1. Extraxt zip file and past folder under the xampp/htdocs/task
2. Creare database "test" and import  test.sql file
3. Run the file http://localhost/task/index.php
4. Click import button import json file into database
