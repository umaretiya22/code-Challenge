<?php
    require_once "database/db.php";
    require_once "constant/constants.php";

class Products
{
    private $db;

    public function __construct() {
        $this->db = new DB(); // Create an instance of the DB class
    }

    public function getFilteredProducts($search)
    {
        $sql = "SELECT customers.customerName AS customer, products.productName AS product, products.productPrice as price
                FROM sales 
                INNER JOIN products ON sales.productId = products.id 
                INNER JOIN customers ON sales.customerId = customers.id WHERE 1=1";

        $params = array();
        $whereClauses = array();

        if (!empty($search['customer'])) {
            $whereClauses[] = "customers.customerName LIKE ?";
            $params[] = '%' . $search['customer'] . '%';
        }
        if (!empty($search['product'])) {
            $whereClauses[] = "products.productName LIKE ?";
            $params[] = '%' . $search['product'] . '%';
        }
        if (!empty($search['price'])) {
            $whereClauses[] = "products.productPrice = ?";
            $params[] = $search['price'];
        }

        if (!empty($whereClauses)) {
            $sql .= " AND " . implode(" AND ", $whereClauses);
        }

        $sales = $this->db->query($sql, $params);
        return $sales;
    }
}
?>
