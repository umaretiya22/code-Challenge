<?php

class DB {
    private $servername = "localhost";
    private $username = "root";
    private $password = "";
    private $dbname = "test";
    private $conn;

    public function __construct() {
        try {
            // Create a new PDO connection
            $this->conn = new PDO("mysql:host={$this->servername};dbname={$this->dbname}", $this->username, $this->password);

            // Set PDO to throw exceptions on error
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            // If connection fails, terminate with error message
            die("Connection failed: " . $e->getMessage());
        }
    }

    public function query($sql, $params = array()) {
        try {
            // Prepare statement
            $stmt = $this->conn->prepare($sql);

            // Bind parameters if any
            if (!empty($params)) {
                $i = 1;
                foreach ($params as $param) {
                    $stmt->bindValue($i, $param);
                    $i++;
                }
            }

            // Execute query
            $stmt->execute();

            // Return result set
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            // If query fails, terminate with error message
            die("Query failed: " . $e->getMessage());
        }
    }

    public function insert($tableName, $data) {
        // Prepare SQL statement
        $fields = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        $sql = "INSERT INTO $tableName ($fields) VALUES ($placeholders)";

        try {
            // Prepare and execute statement
            $stmt = $this->conn->prepare($sql);
            $stmt->execute(array_values($data));

            // Return the auto-generated ID of the inserted row
            return $this->conn->lastInsertId();
        } catch(PDOException $e) {
            // If insertion fails, terminate with error message
            die("Insert failed: " . $e->getMessage());
        }
    }

    public function __destruct() {
        // Close connection
        $this->conn = null;
    }
}
?>
