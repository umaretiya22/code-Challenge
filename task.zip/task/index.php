<?php
    include "importDB.php";
    include "getProducts.php";

    if (!empty($_POST['import'])) {
        try {
            $importDB = new ImportDB();
            $importDB->importTable();
            $success=true;

        } catch (\PDOException  $e) {
            echo "Transaction failed: " . $e->getMessage();
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Task</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <br>
    <form method="post" class="form-inline form-group">
        <input type="submit" name="import" value="import Database" class="btn btn-default">
    </form>

    <form method="GET"  class="form-inline">
        <div class="form-group">
            <label>Customer</label>
            <input type="text" name="customer" value="<?php echo @$_GET['customer']; ?>" class="form-control" >
        </div>
        <div class="form-group">
            <label>Product</label>
            <input type="text" name="product" value="<?php echo @$_GET['product']; ?>" class="form-control" >
        </div>

        <div class="form-group">
            <label>Price</label>
            <input type="text" name="price" value="<?php echo @$_GET['price']; ?>" class="form-control" >
        </div>

        <input type="submit" value="Filter" class="btn btn-default">
    </form>
    <br>

    <?php
        if(isset($success)){
            echo '<div class="alert alert-success"><strong>Database!</strong> import successfully.</div>';
        }

        $getProducts = new Products();
        $sales = $getProducts->getFilteredProducts($_GET);
    ?>
    <table class="table">
        <tr>
            <th>Customer</th>
            <th>Product</th>
            <th>Price</th>
        </tr>
        <?php
        $totalPrice = 0;
        foreach ($sales as $sale) {
            echo "<tr>";
            echo "<td>{$sale['customer']}</td>";
            echo "<td>{$sale['product']}</td>";
            echo "<td>{$sale['price']}</td>";
            echo "</tr>";
            $totalPrice += $sale['price'];
        }
        ?>
        <tr>
            <td colspan="2"><strong>Total Price:</strong></td>
            <td><strong><?php echo $totalPrice; ?></strong></td>
        </tr>
    </table>
</div>
</body>
</html>
