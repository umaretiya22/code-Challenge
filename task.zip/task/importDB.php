<?php
require_once "database/db.php";
require_once "constant/constants.php";

class ImportDB
{
    private $db;

    public function __construct() {
        $this->db = new DB(); // Create an instance of the DB class
    }

    public function importTable()
    {
        $salesJsonArr = file_get_contents("json/sales.json");
        $salesData = json_decode($salesJsonArr, true);

        foreach ($salesData as $key => $value) {
          
            $customerId =  $this->db->insert(CUSTOMER_TABLE, [
                "customerName" => $value["customer_name"],
                "email" => $value["customer_mail"],
            ]);
            $productId = $this->db->insert(PRODUCT_TABLE, [
                "productName" => $value["product_name"],
                "productPrice" => $value["product_price"],
            ]);

            $this->db->insert(SALES_TABLE, [
                "productId" => $productId,
                "customerId" => $customerId,
            ]);
        }

        return true;
    }
}
?>
