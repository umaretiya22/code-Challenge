<?php
 /* Database tables name constant*/
    define('CUSTOMER_TABLE', 'customers');
    define('PRODUCT_TABLE', 'products');
    define('SALES_TABLE', 'sales');
?>